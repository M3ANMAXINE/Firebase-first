export default {
  apiKey: "AIzaSyCuMLm4DvYGfyAzIFi3NA8i7m8IMOgWcmI",
  authDomain: "testfirebase-4f662.firebaseapp.com",
  databaseURL: "https://testfirebase-4f662.firebaseio.com",
  projectId: "testfirebase-4f662",
  storageBucket: "testfirebase-4f662.appspot.com",
  messagingSenderId: "306319017981",
  appId: "1:306319017981:web:d2eb460c067e6f5a7ffb94"
}